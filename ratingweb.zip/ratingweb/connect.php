<?php
ini_set('default_charset', 'UTF-8');
$con = mysqli_connect("localhost","root","","rating");
mysqli_query($con,"SET NAMES 'utf8' ;");

?>