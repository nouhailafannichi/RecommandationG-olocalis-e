<?php
require('connect.php');
$response = array();
$json = file_get_contents('php://input');
$input = json_decode($json);
if (!empty($input->nom) && !empty($input->prenom) && !empty($input->email) && !empty($input->password)) {
    $nom = $input->nom;
    $prenom = $input->prenom;
    $email = $input->email;
    $password = $input->password;
    $sql = "select * from user where email like '$email'";
    $result = $con->query($sql);
    $records = mysqli_num_rows($result);
    if ($records > 0) {
        $response["success"] = -1;
        $response["reason"] = "Email already exists.";
    } else {
        $sql = "insert into user (`nom`, `prenom`, `email`, `password`) values ('$nom','$prenom','$email','$password')";

        if ($con->query($sql) === TRUE) {
            $last_id = $con->insert_id;
            $response["user_id"] = $last_id;
            $response["success"] = 1;
        } else {
            $response["success"] = 0;
        }
    }

} else {
    $response["reason"] = "tous les champs sont obligatoires !";
    $response["success"] = 0;
}
echo json_encode($response);
mysqli_close($con);
?>