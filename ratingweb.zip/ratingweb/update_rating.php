<?php
require('connect.php');
$response = array();
if (!empty($_GET['value']) && !empty($_GET['user_id']) && !empty($_GET['item_id'])) {
    $value = $_GET['value'];
    $userId = $_GET['user_id'];
    $itemId = $_GET['item_id'];

    $sql = "update ratings set value = $value where user_id = $userId and item_id = $itemId";

    if ($con->query($sql) === TRUE) {
        $response["success"] = 1;
    } else {
        $response["success"] = 0;
    }

} else {
    $response["reason"] = "Missing value/userID/itemID";
    $response["success"] = -2;
}
echo json_encode($response);
mysqli_close($con);
?>