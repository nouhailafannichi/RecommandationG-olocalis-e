<?php
require('connect.php');
$response = array();
if (!empty($_GET['type'])) {
    $response["success"] = 1;
    $response["items"] = array();
    $type = $_GET['type'];

    $result = mysqli_query($con, "SELECT * FROM item where `type` like '$type'");
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $Facts = array();
            $Facts['id'] = $row[0];
            $Facts['type'] = $row[1];
            $Facts['nom'] = $row[2];
            $Facts['description'] = $row[3];
            $Facts['image'] = $row[4];
            $Facts['prix'] = $row[5];

            $id = $Facts['id'];
            $result2 = mysqli_query($con, "SELECT AVG(value) AS rating FROM ratings where `item_id` = $id");
            if (mysqli_num_rows($result2) > 0) {
                while ($row = mysqli_fetch_array($result2)) {
                    $Facts['rating'] = $row[0] != null ? $row[0] : 0 ;
                }

            }

            array_push($response["items"], $Facts);
        }

    }

} else {
    $response["reason"] = "Missing item type/sort criteria";
    $response["success"] = 0;
}
echo json_encode($response);
mysqli_close($con);
?>