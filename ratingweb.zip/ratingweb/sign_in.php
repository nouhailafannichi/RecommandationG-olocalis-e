<?php
require('connect.php');
$json = file_get_contents('php://input');
$input = json_decode($json);
$response = array();
if (!empty($input->email) && !empty($input->password)) {
    $email = $input->email;
    $password = $input->password;
    $result = mysqli_query($con, "SELECT * FROM user where email like '$email' and password like '$password'");
    if (mysqli_num_rows($result) > 0) {
        $response["success"] = 1;
        $response["user"] = array();
        while ($row = mysqli_fetch_array($result)) {
            $Facts = new class {
                public $userID;
                public $nom;
                public $prenom;
                public $email;
                public $password;
            };
            $Facts->id = $row[0];
            $Facts->nom = $row[1];
            $Facts->prenom = $row[2];
            $Facts->email = $row[3];
            $Facts->password = $row[4];

            $response["user"] = $Facts;
        }

    } else {
        $response["success"] = -1;
        $response["reason"] = "Invalid credentials.";
    }
} else {
    $response["reason"] = "Missing email/password.";
    $response["success"] = 0;
}
echo json_encode($response);
mysqli_close($con);
?>