<?php
require('connect.php');
$response = array();
if (true) {
    $response["success"] = 1;
    $response["users"] = array();
    $result = mysqli_query($con, "SELECT * FROM user");
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $Facts = array();
            $Facts['id'] = $row[0];
            $Facts['nom'] = $row[1];
            $Facts['prenom'] = $row[2];
            $Facts['email'] = $row[3];
            $Facts['password'] = $row[4];

            array_push($response["users"], $Facts);
        }
    }
}
echo json_encode($response);
mysqli_close($con);
?>