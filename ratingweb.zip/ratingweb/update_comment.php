<?php
require('connect.php');
$response = array();
if (!empty($_GET['content']) && !empty($_GET['userID']) && !empty($_GET['itemID'])) {
    $content = $_GET['content'];
    $userId = $_GET['userID'];
    $itemId = $_GET['itemID'];

    $sql = "update comment set content = '$content', date = NOW() where user_id = $userId and item_id = $itemId";

    if ($con->query($sql) === TRUE) {
        $response["success"] = 1;
    } else {
        $response["success"] = 0;
    }

} else {
    $response["reason"] = "Missing comment/userID/itemID";
    $response["success"] = -1;
}
echo json_encode($response);
mysqli_close($con);
?>