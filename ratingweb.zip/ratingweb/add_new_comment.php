<?php
require('connect.php');
$response = array();
if (!empty($_GET['content']) && !empty($_GET['userID']) && !empty($_GET['itemID'])) {
    $content = $_GET['content'];
    $userId = $_GET['userID'];
    $itemId = $_GET['itemID'];
    $result = mysqli_query($con, "SELECT * FROM comment where `item_id` = $itemId AND user_id = $userId");
    $records = mysqli_num_rows($result);
    if ($records > 0) {
        $response["success"] = -1;
        $response["reason"] = "User has comment already.";
    } else {
        $sql = "insert into comment (`content`, `user_id`, `item_id`, `date`) values ('$content','$userId','$itemId', NOW())";

        if ($con->query($sql) === TRUE) {
            $last_id = $con->insert_id;
            $response["commentID"] = $last_id;
            $response["success"] = 1;
        } else {
            $response["success"] = 0;
        }
    }

} else {
    $response["reason"] = "Missing comment/userID/itemID";
    $response["success"] = -2;
}
echo json_encode($response);
mysqli_close($con);
?>