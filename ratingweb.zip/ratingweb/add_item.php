<?php
require('connect.php');
$json = file_get_contents('php://input');
$input = json_decode($json);
$response = array();
try {
    $final_img_name = "";
    if (
        !isset($_FILES['photo']['error']) ||
        is_array($_FILES['photo']['error'])
    ) {
        $response["success"] = -9;
        $response["reason"] = 'Invalid parameters.';
        goto label;
    }

    $error = false;
    switch ($_FILES['photo']['error']) {
        case UPLOAD_ERR_OK:
            break;
        case UPLOAD_ERR_NO_FILE:
            $error = true;
            $response["success"] = -8;
            $response["reason"] = 'No file sent.';
            break;
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            $error = true;
            $response["success"] = -7;
            $response["reason"] = 'Exceeded filesize limit.';
        default:
            $error = true;
            $response["success"] = -6;
            $response["reason"] = 'Unknown errors.';
    }

    if ($error) {
        goto label;
    }

    // You should also check filesize here.
    if ($_FILES['photo']['size'] > 10000000) {
        $response["success"] = -5;
        $response["reason"] = 'Exceeded filesize limit.';
        goto label;
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    if (false === $ext = array_search(
            $finfo->file($_FILES['photo']['tmp_name']),
            array(
                'jpg' => 'image/jpeg',
                'png' => 'image/png',
                'gif' => 'image/gif',
            ),
            true
        )) {
        $response["success"] = -4;
        $response["reason"] = 'Invalid file format.';
        goto label;
    }

    if (!move_uploaded_file(
        $_FILES['photo']['tmp_name'],
        $final_img_name = sprintf('./uploads/%s.%s',
            sha1_file($_FILES['photo']['tmp_name']),
            $ext
        )
    )) {
        $response["success"] = -3;
        $response["reason"] = 'Failed to move uploaded file.';
        goto label;
    }

    $type = strip($_POST['type']);
    $nom = strip($_POST['nom']);
    $description = strip($_POST['description']);
    $prix = strip($_POST['prix']);
    $sql = "insert into item (`type`, `nom`, `description`, `image`, `prix`) values ('$type','$nom','$description', '$final_img_name', $prix)";

    if ($con->query($sql) === TRUE) {
        $last_id = $con->insert_id;
        $response["item_id"] = $last_id;
        $response["success"] = 1;
        $response["reason"] = 'File is uploaded successfully.';
    } else {
        $response["success"] = -10;
        $response["reason"] = 'error inserting item';
    }


} catch (RuntimeException $e) {
    $response["success"] = -2;
    $response["reason"] = $e->getMessage();
    // Ecole, hotel, piscine
}
label:
echo json_encode($response);
mysqli_close($con);

function strip($string)
{
    return str_replace(array("\"", "'"), '', $string);
}

?>