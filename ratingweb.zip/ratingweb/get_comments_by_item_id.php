<?php
require('connect.php');
$json = file_get_contents('php://input');
$input = json_decode($json);
$response = array();
if (!empty($_GET['item_id']) && !empty($_GET['user_id'])) {
    $response["success"] = 1;
    $response["comments"] = array();
    $itemId = $_GET['item_id'];
    $userId = $_GET['user_id'];
    $result = mysqli_query($con, "SELECT * FROM comment where `item_id` = $itemId ORDER BY date DESC");
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $Facts = array();
            $Facts['id'] = $row[0];
            $Facts['content'] = $row[1];
            $Facts['userID'] = $row[2];
            $Facts['itemID'] = $row[3];
            $Facts['date'] = $row[4];

            array_push($response["comments"], $Facts);
        }

        $result = mysqli_query($con, "SELECT * FROM comment where `item_id` = $itemId AND user_id = $userId");
        if (mysqli_num_rows($result) > 0) {
            $response["user_has_comment"] = true;
            while ($row = mysqli_fetch_array($result)) {
                $Facts = array();
                $Facts['id'] = $row[0];
                $Facts['content'] = $row[1];
                $Facts['userID'] = $row[2];
                $Facts['itemID'] = $row[3];
                $Facts['date'] = $row[4];

                $response["user_comment"] = $Facts;
            }

            $result = mysqli_query($con, "SELECT value FROM ratings where `item_id` = $itemId AND user_id = $userId");
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_array($result)) {
                    $response["user_rating"] = $row[0];
                }

                $result2 = mysqli_query($con, "SELECT AVG(value) AS rating FROM ratings where `item_id` = $itemId");
                if (mysqli_num_rows($result2) > 0) {
                    while ($row = mysqli_fetch_array($result2)) {
                        $response['rating'] = $row[0] != null ? $row[0] : 0 ;
                    }

                }
            }
        }
        else {
            $response["user_has_comment"] = false;
        }
    }
    else {
        $response["user_has_comment"] = false;
    }
} else {
    $response["reason"] = "Missing item id or user id.";
    $response["success"] = 0;
}
echo json_encode($response);
mysqli_close($con);
?>